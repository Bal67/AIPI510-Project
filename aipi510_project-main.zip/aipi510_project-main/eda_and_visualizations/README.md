# EDA and Visualizations


This folder contains our scripts and notebooks for some of the EDA and visualizations that we created for our datasets. For feature importance exploration, see the models folder.


## visualizations.py
This file creates general visualizations using our fully joined dataset. The outputs of these can be see in the visualizations subfolder, and it contains summary information for demographics such as free lunch students, school populations, and number of teachers.

## saipe_funding_exploration.ipynb
This file reads in data from the SAIPE API and funding information from the US Department of Education. For more information on these, check out the data README. This does some basic visualizations and gets summary statistics for some characteristics of these datasets, such as poverty rates and funding over time. The figures are exported into the saipe_funding_visualizations subfolder, but the summary statistics are only in the notebook.

## ed_data_express_visualizations.ipynb
This file reads in data from the ED Data Express dataset, and for more information on that, check out the data README. This does some visualizations on the relationships between school improvement funds and graduation rate and the results can be found in the ed_data_express_visualizations subfolder.


