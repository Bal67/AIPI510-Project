import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.types import Integer
from sqlalchemy.orm import sessionmaker
import os
import requests
import warnings
import copy

warnings.filterwarnings("ignore")

class Sources:
    """
    Class to ingest the data from various sources and directly update the database to 
    create the tables used in the project

    """

    def __init__(self, hostname, schema, username, password):
        """
        Set up the MySQL ODBC connection and the sqlalchemy engine to run the queries on
        
        """

        connection_str = f'mysql+mysqlconnector://{username}:{password}@{hostname}:3306/{schema}'
        self.engine = create_engine(str(connection_str))
        Session = sessionmaker(bind=self.engine)
        self.session = Session()
        self.data_directory = os.path.dirname(os.path.abspath(__file__))


    def ed_data_express_data(self):
        """
        Takes the extract files from the ED Data Express dataset on their graduation rates, Title 1 statuses, and
        various funding information, merges the files together, and creates a consumption table in the database.
        
        Returns: df
        
        """
        def read_data(data_partA, data_allparts, gradrate):
            data_partA = pd.read_csv(data_partA) 
            data_allparts = pd.read_csv(data_allparts)
            data_gradrate = pd.read_csv(gradrate)
            return data_partA, data_allparts, data_gradrate

        #Reading the CSV files 

        title1APath = os.path.join(self.data_directory, "ed_data_express", "Title1A.csv")
        title1AAllPath = os.path.join(self.data_directory, "ed_data_express", "Title1A.csv")
        gradRatePath = os.path.join(self.data_directory, "ed_data_express", "Title1A.csv")
        partA, allparts, grad = read_data(title1APath, title1AAllPath, gradRatePath)
        
        #Filtering Data in CSV Title 1 Part A
        partA = partA.drop(columns = ['Data Description',
                                    'Data Group','Denominator', 'Numerator', 
                                    'Subgroup', 'Characteristics', 'Age/Grade', 'Academic Subject', 
                                    'Program Type', 'Outcome'])
                        

        #Filtering data in Title 1 All Parts
        allparts = allparts.drop(columns = ['Data Description',
                                            'Data Group','Denominator', 'Numerator', 
                                            'Subgroup', 'Characteristics', 'Age/Grade', 
                                            'Academic Subject', 'Program Type', 'Outcome'])


        #Filtering Data is Grad
        grad = grad.drop(columns = ['Data Description','Data Group','Denominator', 'Numerator', 
                                    'School', 'Age/Grade', 'Academic Subject', 
                                    'Population', 'Outcome', 'Characteristics', 'Program Type'])
        grad = grad.drop(grad[(grad['Value'] == '') | (grad['Value'] == 'S')].index)



        # Merge the DataFrames
        merged_df = pd.merge(partA, allparts, on='LEA', how='inner')
        merged_df = pd.merge(merged_df, grad, on='LEA', how='inner')


        #Cleaning new dataframe
        merged_df = merged_df.drop(columns = ['School_x', 'Population_x', 'School Year_y', 'State_y', 
                                            'Value_y', 'School Year', 'State'])

        #Renaming Columns
        merged_df = merged_df.rename(columns = {'School Year_x' : 'School Year', 
                                            'State_x' : 'State',
                                            'Value_x' : 'School Improvement Funds',
                                            'Value' : 'Graduation Rates',
                                            'Population_y' : 'School Type',
                                            'School_y' : 'School'})

        # Filtering the Columns for Certain Specifications
        merged_df = merged_df[merged_df['School'].str.contains(r'\bHigh School\b')]
        merged_df = merged_df[~merged_df['School'].str.contains('Junior')]


        # Removing duplicate values in the 'Graduation Rates' column
        merged_df = merged_df.drop_duplicates(subset=['Graduation Rates'])
        
        try:
            merged_df.to_sql(name="graduation_rates", con=self.engine, if_exists='replace')
        except Exception as e:
            print(e)
            
        return merged_df


    def saipe_api_data(self):
        """
        Uses an API from census.gov to pull data from the SAIPE dataset. This merges together the 
        SAIPE data from a set start and end year and creates a consumption table in the database.
        
        Returns: df
        
        """
        # Lousiana corresponds to state 22
        def getSAIPEDistrictData(state = 22, start_year = 2017, end_year = 2022):
            url = "https://api.census.gov/data/timeseries/poverty/saipe/schdist"

            # The get is all of the relevant poverty metrics used for a specific school district
            params = {
                "get": "SD_NAME,SAEPOV5_17RV_PT,SAEPOV5_17V_PT,SAEPOVRAT5_17RV_PT",
                "for": "school district (Unified):*",
                "in": f"state:{state}",
                "YEAR": f"{start_year}:{end_year}",
            }

            response = requests.get(url, params=params)

            if response.status_code == 200:
                data = response.json()
                # The first row is the header row, so we only get data from 1 and beyond
                df = pd.DataFrame(data[1:], columns=["District Name","Pop. in Poverty","Population","Poverty Ratio Estimate","Year","State Code","LEA ID"]) 
                df[["Pop. in Poverty","Population","Poverty Ratio Estimate"]] = df[["Pop. in Poverty","Population","Poverty Ratio Estimate"]].apply(pd.to_numeric)
                # Add 22 to the LEA ID so that it is formatted in the same way as our other datasets.
                df['LEA ID'] = '22' + df['LEA ID'].astype(str)
                return df
            else:
                print("API request failed with status code:", response.status_code)
        df = getSAIPEDistrictData()
        try:
            df.to_sql(name="saipe", con=self.engine, if_exists='replace')
        except Exception as e:
            print(e)
            
        return df

    def ssle_data(self):
        """
        Takes the extract files from the SSLE dataset and creates a consumption table in the database
        
        Returns: df
        
        """
        sslePath = os.path.join(self.data_directory, "ssle", "SSLE.csv")
        df = pd.read_csv(sslePath)
        try:
            df.to_sql(name="ssle", con=self.engine, if_exists='replace')
        except Exception as e:
            print(e)
        
        return df

    def graduation_rate_by_category(self):
        """
        Takes the extract files from the EDFacts ACGR dataset on their graduation rates and
        merges the files together to create a consumption table in the database
        
        Returns: df
        
        """
        base_path = os.path.join(self.data_directory, "graduation_rate_by_category")
        # 2018 to 2020 and 2015 to 2017 are treated differently due to different file formats between those years
        years = [2018,2019,2020]
        dfs = []
        for year in years:
            df = pd.read_csv(os.path.join(base_path, f"graduation_rate_by_category_{year}.csv"))
            df['NCESSCH'] = df['NCESSCH'].astype(str)
            df['YEAR'] = df['SCHOOL_YEAR'].str.split("-").str.get(0)
            dfs.append(df)
            
        # These files add all data for a specific school by the column vs. the other years that have them by row.
        # This extracts the relevant columns and reconstructs them into the format of the other files.
        years = [2015,2016,2017]
        for year in years:
            df = pd.read_csv(os.path.join(base_path, f"graduation_rate_by_category_{year}.csv"))
            suffix = f'{str(year)[-2:]}{str(year+1)[-2:]}'
            temp_df = df[['STNAM','FIPST','LEAID', 'ST_LEAID', 'LEANM', 'NCESSCH','ST_SCHID','SCHNAM',f'ALL_COHORT_{suffix}',f'ALL_RATE_{suffix}','DATE_CUR']]
            temp_df = temp_df.rename(columns = {f'ALL_COHORT_{suffix}': 'COHORT', f'ALL_RATE_{suffix}': 'RATE'})
            temp_df['YEAR'] = year
            temp_df['NCESSCH'] = temp_df['NCESSCH'].astype(str)
            temp_df['SCHOOL_YEAR'] = f'{year}-{year+1}'
            temp_df['CATEGORY'] = 'ALL'
            dfs.append(temp_df)
         
        df = pd.concat(dfs)
        try:
            df.to_sql(name="graduation_rate_category", con=self.engine, if_exists='replace')
        except Exception as e:
            print(e)
        
        return df
    
    def max_eligible_funding(self):
        """
        Accesses the URLs of the maximum Title I funding allocations per district in Lousiana and 
        reads and merges the results together to create a consumption table in the database.
        This is defaulted to getting the data from 2015 to 2020.
        
        Returns: df
        
        """
        # This gets the funding distribution for a single year by accessing and downloading directly from 
        # the url. 2020 is treated differently, because their website switched from xls to xlsx in just that year.
        def getFundingDistribution(year=2020):
            if year > 2020 or year < 2002:
                print("no data")
                return

            if year == 2020:
                url="https://www2.ed.gov/about/overview/budget/titlei/fy20/louisiana.xlsx"
            else:
                url= f"https://www2.ed.gov/about/overview/budget/titlei/fy{year%2000}/louisiana.xls"

            funding_df=pd.read_excel(url, names=["LEA ID", "District Name", "Funding Allocation"])
            # The read in excel file has some extra rows before the actual columns, so we start by finding the index row.
            index_row = funding_df[funding_df.iloc[:, 0] == "LEA ID"].index.astype(int)[0]
            # There are always 70 non-na rows after the index row, corresponding to the districts in Lousiana
            funding_df = funding_df.iloc[index_row+1:].dropna().iloc[:70]
            funding_df[["Funding Allocation"]] = funding_df[["Funding Allocation"]].apply(pd.to_numeric)
            funding_df[["Year"]] = year
            return funding_df

        # This just runs the previous function and maps it over multiple years to get a single dataset
        def getFundingDistributionMultipleYears(start_year = 2015, end_year = 2020):
            dfs = []
            for i in range(start_year,end_year+1):
                dfs.append(getFundingDistribution(i))
            return pd.concat(dfs)
        df = getFundingDistributionMultipleYears()
        try:
            df.to_sql(name="title_i_max_funding", con=self.engine, if_exists='replace')
        except Exception as e:
            print(e)
        
        return df
    
    def nces_by_year(self):
        """
        Takes the extract files from the National Center for Education Statistics
        and joins them together to create a consumption table for ingest. Also returns
        the consumption table as a dataframe.

        Returns: df

        """
        base_path = os.path.join(self.data_directory, "nces")

        first_csv = True

        for file in os.listdir(base_path):
            filename = os.fsdecode(file)
            path = os.path.join(base_path, filename)

            if filename.endswith(".csv"): 
                if first_csv:
                    df = pd.read_csv(path)
                    first_csv = False
                else:
                    cols_to_use = pd.read_csv(path).columns.difference(df.columns).tolist()
                    cols_to_use.append("Agency ID - NCES Assigned [Public School] Latest available year")
                    cols_to_use.append("School Name")
                    df = df.merge(pd.read_csv(path)[cols_to_use], how="inner", on=["School Name", "Agency ID - NCES Assigned [Public School] Latest available year"])

        df = df.rename(str.lower, axis='columns')

        columns_dict = {}
        for i in df.columns:
            columns_dict[i] = i
            if columns_dict[i] .find("[public school]") != -1:
                columns_dict[i] = columns_dict[i] .replace("[public school]", "")
            if columns_dict[i] .find("  ") != -1:
                columns_dict[i] = columns_dict[i] .replace("  ", " ")
            if columns_dict[i] .find(" latest available year") != -1:
                columns_dict[i] = columns_dict[i] .replace(" latest available year", "")
            if columns_dict[i] .find(" ") != -1:
                columns_dict[i] = columns_dict[i] .replace(" ", "_")
            if columns_dict[i] .find("-") != -1:
                columns_dict[i] = columns_dict[i] .replace("-", "_")
            if columns_dict[i] .find("/") != -1:
                columns_dict[i] = columns_dict[i] .replace("/", "_")
            if columns_dict[i] .find("(") != -1:
                columns_dict[i] = columns_dict[i] .replace("(", "_")
            if columns_dict[i] .find(")") != -1:
                columns_dict[i] = columns_dict[i] .replace(")", "_")
            if columns_dict[i] .find(".") != -1:
                columns_dict[i] = columns_dict[i] .replace(".", "_")
            if columns_dict[i] .find("hawaiian_or_other_pacific_isl") != -1:
                columns_dict[i] = columns_dict[i] .replace("hawaiian_or_other_pacific_isl", "pacific_isl")
            while columns_dict[i] .find("__") != -1:
                columns_dict[i] = columns_dict[i] .replace("__", "_")
            columns_dict[i] = columns_dict[i].strip()

        df = df.rename(columns=columns_dict)
        # These are excess columns as it already has state, school, and county name
        df = df.drop(columns = ["state_name_2021_22","school_name_2021_22","county_name_2021_22"])

        # This section splits out the columns into rows by year. Before, each row would contain a single row for the 
        # school, and there would be columns giving statistics for each of the years of data that they want.
        # We wanted to split it up so that the years are in the rows so we can join to this dataset more easily
        # to other datasets that are by year, and this makes a row for every school/year combination.
        def split_to_years(df):
            #This gets the columns that have specific year information associated to them (ex. end in something like year_year)
            year_split_cols = df.columns[df.columns.str[-2:].map(lambda x: x.isdigit())]
            # These gives the unique prefixes for the columns that can be split by year
            prefixes = year_split_cols.str.split('_').str[:-2].map(lambda x: '_'.join(x)).unique()
            years = ["2020_21", "2021_22", "2019_20", "2018_19", "2017_18", "2016_17", "2015_16", "2014_15"]
            other_cols = df.columns[df.columns.str[-2:].map(lambda x: not x.isdigit())]
            col_list = list(other_cols) + list(prefixes) + ['Year']

            col_dict = {col: None for col in col_list}

            # This lets us have a dictionary to put partial results into as we iterate
            template_dict = {year: col_dict.copy() for year in years}
            for year in years:
                template_dict[year]['Year'] = year.split("_")[0]

            # Iterate through the current dataframe, and map the by year columns to a by year row
            df_list = []
            for i in range(len(df)):
                row = df.iloc[i,:]
                row_dict = copy.deepcopy(template_dict)
                for j in row.index:
                    if j in year_split_cols:
                        col_year = "_".join(j.split("_")[-2:])
                        prefix = "_".join(j.split("_")[:-2])
                        if col_year in row_dict:
                            row_dict[col_year][prefix] = row[j]
                    else:
                        for year in row_dict:
                            row_dict[year][j] = row[j]
                df_list = df_list + list(row_dict.values())
            return pd.DataFrame(df_list)
        
        final_df = split_to_years(df)
        try:
            final_df.to_sql(name="nces_by_year", con=self.engine, if_exists='replace')
        except Exception as e:
            print(e)
        return final_df

    def per_pupil_data(self):
        """
        Takes the extract files from the state of Louisiana Department of Education on their per-pupil expenditure and 
        merges the files together to create a consumption table in the database
        
        Returns: df
        
        """
        base_path = os.path.join(self.data_directory, "Per Pupil Data")

        first_csv = True

        for file in os.listdir(base_path):
            filename = os.fsdecode(file)
            path = os.path.join(base_path, filename)

            if filename.endswith(".csv"): 
                if first_csv:
                    df = pd.read_csv(path, thousands=',').astype(str)
                    first_csv = False
                else:                    
                    df = pd.concat([df, pd.read_csv(path, thousands=',').astype(str)])

        df = df.rename(str.lower, axis='columns')
        
        columns_dict = {}
        for i in df.columns:
            columns_dict[i] = i
            if columns_dict[i] .find("  ") != -1:
                columns_dict[i] = columns_dict[i] .replace("  ", " ")
            if columns_dict[i] .find(" ") != -1:
                columns_dict[i] = columns_dict[i] .replace(" ", "_")
            if columns_dict[i] .find("-") != -1:
                columns_dict[i] = columns_dict[i] .replace("-", "_")
            if columns_dict[i] .find("/") != -1:
                columns_dict[i] = columns_dict[i] .replace("/", "_")
            if columns_dict[i] .find("(") != -1:
                columns_dict[i] = columns_dict[i] .replace("(", "_")
            if columns_dict[i] .find(")") != -1:
                columns_dict[i] = columns_dict[i] .replace(")", "_")
            if columns_dict[i] .find(".") != -1:
                columns_dict[i] = columns_dict[i] .replace(".", "_")
            while columns_dict[i] .find("__") != -1:
                columns_dict[i] = columns_dict[i] .replace("__", "_")
            columns_dict[i] = columns_dict[i].strip()

        df = df.rename(columns=columns_dict)
        df['Year'] = df['reporting_year'].str.split("-").str[0]
        df = df.drop(columns = ['reporting_year'])
        # This converts it into a float instead of a string as some are in the format (6,799). We also strip out percentages
        # as we don't use the categories associated with percents.
        df['amount_or_percent'] = df['amount_or_percent'].str.rstrip('%').str.strip().str.replace(',', '').astype(float)
        print(df)

        try:
            df.to_sql(name="per_pupil_data", con=self.engine, if_exists='replace')
            self.session.commit()
        except Exception as e:
            self.session.rollback()
            print(e)
        return df


if __name__=="__main__": 
    # Initialize the database connection and add each of the datasets to the database
    data = Sources("localhost", "aipi510_project", "root", "password")

    df = data.ed_data_express_data()
    df = data.saipe_api_data()
    df = data.ssle_data()
    df = data.graduation_rate_by_category()
    df = data.max_eligible_funding()
    df = data.nces_by_year()
    df = data.per_pupil_data()

