# Data


The sources.py script reads in data from various sources and inserts it directly into the specified MySQL database. To set up the MySQL database, check out the README in the main directory. To run this script, you can just run python sources.py.

## Summary of Data Sources

This section will go over the data sources used, how they were obtained, and what information we get from them. These will be in order of how they appear in the Sources class in sources.py. Because of the differing year ranges of our data, we decided to mainly use the 2016-2020 subset of data as this represented the most complete dataset that we could get from each of these sources.

### ED Data Express Data (ed_data_express_data)

This dataset is obtained from [Ed Data Express](https://eddataexpress.ed.gov/). It is a collection of 3 CSVs stored in the ed_data_express subfolder, and it gives general, per school information about Title I status (Part A and All Parts) as well some graduation rates associated with it as well. This also contains subdivided information on this for specific cohorts as well. It does not cover every school in Lousiana, but it does contain specific school information that is not represented in other sources.

### SAIPE dataset (saipe_api_data)
The SAIPE dataset is obtained through an API by the [US Census Bureau](https://www.census.gov/programs-surveys/saipe/data/api.html). This gives information on the Local Education Agency (LEA) level which is one division higher than schools, and we add this onto the school level information as a predictor in our model. This provides poverty metrics and estimates for children aged 5-17 and is currently being used as a main factor in determining Title I funding by the government.

### SSLE dataset (ssle_data)
The Study of School-Level Expenditure (SSLE) data is a dataset by the [US Department of Education](https://data.ed.gov/dataset/comparability-of-state-and-local-expenditures-among-schools-within-districts-2011) and the CSVs are located in the ssle subfolder. This is not fully up to date, but it does give general information on school statuses (ex. charter school statuses and grade levels offered) as well as historical information on funding. 

### Graduation Rate Dataset (graduation_rate_by_category)
The graduation rate by category dataset is obtained from the [EDFacts Adjusted Cohort Graduation Rate (ACGR)](https://www2.ed.gov/about/inits/ed/edfacts/data-files/index.html#acgr) dataset offered by the Department of Education. These CSVs are located in the graduation_rate_by_category folder, and this dataset only goes from 2015 to 2020. This gives an extensive set of data on the per school graduation rate and is used as what we will be predicting in our model. The 2015-2017 and 2018-2020 CSVs are formatted differently, and our preprocessing steps for the two sets of data are slightly different.

### Max Eligible Title I Funding Dataset (max_eligible_funding)
The Max Eligible Title I funding dataset is obtained from the [US Department of Education](https://www2.ed.gov/about/overview/budget/titlei/fy20/index.html). This gives an overview of the estimated and maximum amount of Title I funding a specific district will be allocated in a specific state. As the URLs for the Lousiana specific csvs are similar, this is read directly through accessing the links and is not saved in the data folder. This dataset is useful in understanding how the current set of funding is allocated on a broader scale in the model, and this goes up to 2020.

### NCES Dataset (nces_by_year)
The National Center for Education Statistics (NCES) dataset is obtained from their [ELSI](https://nces.ed.gov/ccd/elsi/) system. The CSVs can be found in the nces subfolder, which contains the various exports needed to get information for the whole state of Lousiana. This gives a lot of demographic information per school from 2014 to 2021, such as the count of people by specific demographics and the number of free and reduced lunch students. It also contains information about the schools like Title I statuses as well. This data is retrieved in a "wide" format where year information is encoded in the columns, so additional processing was done to separate the rows by year.

### Per Pupil Data (per_pupil_data)
The Per Pupil dataset is obtained from the [Louisiana Department of Education](https://www.louisianabelieves.com/resources/library/financial-data). The CSVs can be found in the Per Pupil Data subfolder, which contains the available data from 2016 to 2020. This gives information on the per pupil expenditures for specific schools in Louisiana (as well as per pupil expenditure for specific demographics), and it is used in the model as a predictor for graduation rates.


