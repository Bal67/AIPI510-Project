# AIPI 510 Group 7 Project

=======================================================================
## File Organization
The data folder contains our downloaded data sources and a script that inserts the data into a MySQL database. To see more details on the data sources used, see the README in that folder.

The EDA and Visualizations folder contains some of our visualizations and EDA for the various sets of data that we compiled.

The Models folder contains the model data preparation, training, and demo functions to show the functionality of our model. These are mainly located in the generate_models.ipynb file, and the README in that folder has more details.

The Frontend is just in the main directory, and it can be run after following the setup instructions below with streamlit run ./frontend.py.

## Setup Instructions
=======================================================================

### IN TERMINAL:

pip install -r requirements.txt

=======================================================================

### DATABASE SETUP (Windows Only):

https://dev.mysql.com/downloads/


Install MySQL with an ODBC connection


Run ODBC Data Sources (64 bit) 


Add MySQL ODBC 8.0 ANSI Driver 


IN MYSQL run these commands:

  CREATE SCHEMA aipi510_project;
  
  SET GLOBAL innodb_strict_mode = 0;
  
  SET innodb_strict_mode = 0;

=======================================================================

### RUN PROJECT:

Initialize and insert data into the database:

$ python ./data/sources.py

Run the frontend:

$ streamlit run ./frontend.py

=======================================================================

