# Models


The generate_models Jupyter Notebook reads in our dataset, processes the data, and exports the models into two files: dense_regression_model.h5 and linear_regression_model.pkl. The funding_model.py file does not do training and has the functions in generate_models relating to the demo functions, data preprocessing, and loading in the model. This file is mainly so that our model as well as some particular demo functions can be imported and used for deployment on "real" data (such as the frontend) to avoid having to import functions from the Jupyter Notebook.


## generate_models.ipynb Description
This is the file where we train our models, and you can click run all cells to go through all of the steps. This is divided into 4 main sections (which are also labeled in the file).

### Reading in Data and Preprocessing

In the Reading in Data and Preprocessing section, we pull in the main set of data from the database in the function get_main_data(). This is then passed into get_train_test_data() to split the data and apply one hot encoding and MinMaxScaling. This function also returns a helper function (df_to_model_format) that allows us to convert new data (not just training/test) into the right format and also the scaler to help us see the original values. 

### Feature Exploration

In the Feature Exploration section, we use the SelectKBest features to explore the dataset and also view a correlation matrix of the most highly predicted features. Some of the features were dropped and moved earlier into the pipeline in get_main_data() (ex. removing the feature "Non-personnel expenditures at school level").


### Modeling
In the Modeling section, we test out two models. One is a one layer NN with a sigmoid activation to constrain our outputs to be between 0 and 1 (as graduation rate cannot go outside of that). The other one is a linear regression model. These models were chosen due to their interpretability which is important in this application.


### Demo Function
In the Demo Function section, we create a few utilities to help make use of the results of our model. These are also in the funding_model.py file in order for these to be connected to our frontend. More details on the functions are documented inside the file.


## funding_model.py Description

This file is used to import models into the frontend. The get_funding_model function can be used to get the models directly, along with a function that converts dataframes (that comes from get_main_data()) into the model format (such as encoding and scaling). The get_demo_functions function is used to return the demo functions that can be used in our frontend. These are based off of the 2020 dataset that we did not use to train our model, as a way to show how our model functions on "new" data.


